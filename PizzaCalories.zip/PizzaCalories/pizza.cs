﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaCalories
{
    class pizza
    {
        public pizza(string name,Dough testo)
        {
            this.Name = name;
            this.Testo = testo;
            Topingi = new List<Topping>();
        }
        private string name;

        public string Name
        {
            get { return name; }
            set
            {
                if (value.Length >= 1 && value.Length <= 15 && !(string.IsNullOrEmpty(value))) { name = value; } else { throw new Exception("Pizza name should be between 1 and 15 symbols."); }
                
            }
        }

        private Dough testo;

        public Dough Testo
        {
            get { return testo; }
            set { testo = value; }
        }

        private List<Topping> topingi;

        public List<Topping> Topingi
        {
            get { return topingi; }
            set
            {
                if (value.Count >= 0 && value.Count < 10) { topingi = value; } else { throw new Exception("Number of toppings should be in range [0..10]."); }
                
            }
        }
        
        private double total;

        public double Total
        {
            get { return total; }
            set
            {
                foreach (var item in topingi)
                {
                    value += item.Calories;
                }
                value += testo.Calories;
                total = value;
            }
        }
        public void dobavitopping(Topping gosho)
        {
            topingi.Add(gosho);



        }
        public override string ToString()
        {
            return Name + " - " + string.Format("{0:00.00}",total)+" Calories";
        }

    }
}
