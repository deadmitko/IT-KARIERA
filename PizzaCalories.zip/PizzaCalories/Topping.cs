﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaCalories
{
    class Topping
    {
        public Topping(string type,double weight)
        {
            this.Type = type;
            this.weight = weight;
        }
        private string type;

        public string Type
        {
            get { return type; }
            set
            {
                if (value == "Meat" || value == "Veggies"|| value == "Cheese" || value == "Sauce")
                {
                    type = value;
                }
                else { throw new Exception("Cannot place "+value+" on top of your pizza."); }

            }
        }

        

        private double weight;

        public double Weight
        {
            get { return weight; }
            set
            {
                if (value >= 1 && value < 200) { weight = value; } else { throw new Exception(value+" weight should be in the range [1..50]."); }

            }
        }
        private double meat = 1.2;
        private double veggies = 0.8;
        private double sauce = 0.9;
        private double cheese = 1.1;
        
        private double calories;
        public double Calories
        {
            get { return calories; }
            set
            {
                if (type == "Meat" ) { value = (2 * weight) *meat; }
                else if (type == "Veggies" ) { value = (2 * weight) * veggies; }
                else if (type == "Cheese" ) { value = (2 * weight) *cheese; }
                else if (type == "Sauce") { value = (2 * weight) * sauce; }
                calories = value;

            }
        }
        public override string ToString()
        {
            return string.Format("{0:0.00}", calories);
        }


    }
}
