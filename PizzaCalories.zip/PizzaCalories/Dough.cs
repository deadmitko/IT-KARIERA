﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaCalories
{
    class Dough
    {
        public Dough(string type,string btech,double weight)
        {
            this.Type = type;
            this.Btech = btech;
            this.Weight = weight;
        }
        private string type;

        public string Type
        {
            get { return type; }
            set
            {
                if (value == "White" || value == "Wholegrain" )
                {
                    type = value;
                }
                else { throw new Exception("Invalid type of dough."); }
                
            }
        }

        private string btech;

        public string Btech
        {
            get { return btech; }
            set
            {
                if (value == "Crispy" || value == "Chewy" || value == "Homemade")
                {
                    btech = value;
                }
                else { throw new Exception("Invalid type of dough."); }
            }
        }

        private double weight;

        public double Weight
        {
            get { return weight; }
            set
            {
                if(value>=1 && value < 200) {weight = value; } else { throw new Exception("Dough weight should be in the range [1..200]."); }

            }
        }
        private double whitemod = 1.5;
        private double wholemod = 1.0;
        private double crispymod = 0.9;
        private double chewymod = 1.1;
        private double homemod = 1.0;
        private double calories;
        public double Calories
        {
            get { return calories; }
            set
            {
                if (type == "White" && btech == "Crispy") { value = (2 * weight) * whitemod * crispymod; }
               else if (type == "White" && btech == "Chewy") { value = (2 * weight) * whitemod * chewymod; }
                else if (type == "White" && btech == "Homemade") { value = (2 * weight) * whitemod * homemod; }
                else if (type == "Wholegrain" && btech == "Crispy") { value = (2 * weight) * wholemod * crispymod; }
                else if (type == "Wholegrain" && btech == "Chewy") { value = (2 * weight) * wholemod * chewymod; }
                else { value = (2 * weight) * wholemod * homemod; }

                calories = value;
            }
        }
        public override string ToString()
        {
            return string.Format("{0:0.00}", calories);      
        }


    }
}
