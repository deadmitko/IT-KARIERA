﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PizzaCalories
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var input = Console.ReadLine().Split().ToArray();
                var input2 = Console.ReadLine().Split().ToArray();
                var teglotonatesto = double.Parse(input2[3]);

                Dough testo = new Dough(input2[1], input2[2], teglotonatesto);
                pizza picata = new pizza(input[1], testo);
                Console.WriteLine(testo.Type);
                Console.WriteLine(testo.Weight);
                Console.WriteLine(testo.Calories);
                var input3 = Console.ReadLine().Split().ToArray();
                while (input3[0] == "END")
                {
                    var tegl = double.Parse(input[2]);
                    picata.dobavitopping(new Topping(input[1], tegl));


                    input3 = Console.ReadLine().Split().ToArray();
                }
                picata.ToString();
            }
            catch (Exception k) { Console.WriteLine(k.Message); }

        }
    }
}
