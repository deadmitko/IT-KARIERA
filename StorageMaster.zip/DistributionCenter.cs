﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StorageMaster.Entities.Products;
using StorageMaster.Entities.Storage;
using StorageMaster.Entities.Vehicles;

namespace StorageMaster.Entities.Storage
{
    class DistributionCenter: Storage
    {
        public static readonly List<Vehicle> prevozni = new List<Vehicle>() { new Van(),new Van(),new Van() };



        public DistributionCenter(string name) : base(name, capacity:2, garageslots:5, vehicles:prevozni)
        {

        }
    }
}
