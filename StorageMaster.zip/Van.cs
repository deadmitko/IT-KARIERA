﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StorageMaster.Entities.Products;
using StorageMaster.Entities.Storage;
using StorageMaster.Entities.Vehicles;

namespace StorageMaster.Entities.Vehicles
{
    class Van:Vehicle
    {
        
        public Van() : base(cap: 2)
        {
            tip = "Van";
        }

    }
}
