﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StorageMaster.interfaces
{
   public abstract class Storage
    {
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private int capacity;

        public int Capacity
        {
            get { return capacity; }
            set { capacity = value; }
        }
        private int slots;

        public int Slots
        {
            get { return slots; }
            set { slots = value; }
        }

        private readonly List<Product> producks;

        public IReadOnlyCollection<Product> Producks
        {
            get { return producks; }
           
        }
        public readonly List<Vehicle> garage;

        public IReadOnlyCollection<Vehicle> Garage
        {
            get { return garage; }
            
        }


        private bool isFull;

        public bool IsFull
        {
            get { return isFull; }
            set
            {
                double suma = 0;
                foreach (var item in producks)
                {
                    item.Weight += suma;
                }
                if (suma >= Capacity) { isFull = value = true; }




            }
        }
        private bool pulen;

        public bool Pulen
        {
            get { return pulen; }
            set
            {
                if (Garage.Count >= slots) { pulen = value = true; }

                   

            }
        }

        public Storage(string name,int capacity,int garageslots,IEnumerable<Vehicle> vehicles)
        {
            this.Name = name;
            this.Capacity = capacity;
            this.Slots = garageslots;
            int i = 0;
            foreach (var item in vehicles)
            {
                garage[i++] = item;
            }
        }
       public Vehicle GetVehicle(int slot)
        {
            if (garage.Count == 0) { throw new Exception("No vehicle in garage slot!"); }
            if (slot >= slots && slot <=slots) { return garage[slot]; } else { throw new Exception("Invalid garage slot!"); }





        }
        public int SendVehicleTo(int slot, Storage destination)
        {
            var vehicle = GetVehicle(slot);
            if (destination.pulen) { throw new Exception("No room in garage"); }
            else { destination.garage[slot] = vehicle; }
            return slot;





        }
        public int UnloadVehicle(int garageslot)
        {
            var prevozno = GetVehicle(garageslot);
            var obshto = 0;
            for (int i = 0; i < prevozno.Trunk.Count; i++)
            {
           if (IsFull) { throw new Exception("Storage is full!"); } else { producks.Add(prevozno.Trunk[i]); obshto++; }
            }

            return obshto;



        }
    }
}
