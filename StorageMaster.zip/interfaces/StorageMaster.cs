﻿using StorageMaster.entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StorageMaster.interfaces
{
    class StorageMaster
    {
        Vehicle prevozno;
        Vehicle kola;
        List<Product> pool = new List<Product>();
        List<Storage> storagi = new List<Storage>();
        public string AddProduct(string type, double price)
        {

            switch (type)
            {
                case "Gpu":
                    Gpu gpu = new Gpu(price);
                    pool.Add(gpu);
                    return $"Added {type} to pool";
                    
                case "Ram":
                    Ram ram = new Ram(price);
                    pool.Add(ram);
                    return $"Added {type} to pool";
                    
                case "SolidStateDrive":
                    SolidStateDrive ssd = new SolidStateDrive(price); pool.Add(ssd);
                    return $"Added {type} to pool";
                    
                case "HardDrive":
                    HardDrive hard = new HardDrive(price);
                    pool.Add(hard);
                    return $"Added {type} to pool";
                    
                default:
                    throw new Exception("Invalid product type!");
            }
        }
        public string RegisterStorage(string type, string name)
        {
            switch (type)
            {
                case "AutomatedWarehouse":
                    AutomatedWarehouse gpu = new AutomatedWarehouse(name);
                    storagi.Add(gpu);
                    return $"Registered {name}";
                    
                case "DistributionCenter":
                    DistributionCenter ram = new DistributionCenter(name);
                    storagi.Add(ram);
                    return $"Registered {name}";
                    
                case "Warehouse":
                    Warehouse ssd = new Warehouse(name);
                    storagi.Add(ssd);
                    return $"Registered {name}";
                    
                
                default:
                    
                    return "Invalid product type!";
                    
            }
        }
        public string SelectVehicle(string type, int gslot)
        {
            var car = storagi.Where(x=>x.Name==type).First();
             kola = car.Garage.ElementAt(gslot);
            return "Selected " + kola.tip;
            
            
            
        }
        public string LoadVehicle(IEnumerable<string> productNames)
        {
            
            foreach (var item in productNames)
            {
                kola.LoadProduct(pool.Where(x => x.tip == item).First());
                pool.Remove(pool.Where(x => x.tip == item).First());
            }
            return "Loaded " + kola.Trunk.Count + "/" + productNames.Count() + "products into " + kola.tip;

        }
        public string SendVehicleTo(string sourceName, int sourceGarageSlot, string destinationName)

        {
            Storage source;
            try {  source= storagi.Where(x=>x.Name==sourceName).First(); } catch { throw new Exception("Invalid source"); }
            var prevozno = source.GetVehicle(sourceGarageSlot);
            Storage destination;
            try { destination = storagi.Where(x => x.Name == destinationName).First(); } catch { throw new Exception("Invalid destination"); }
            var destinationindex =source.SendVehicleTo(sourceGarageSlot, destination);
            return $"Sent {prevozno.tip} to {destination.Name} (slot {destinationindex})";
        }
        public string UnloadVehicle(string storageName, int garageSlot)
        {
            Storage source;
            try {source = storagi.Where(x => x.Name == storageName).First(); } catch { throw new Exception("Invalid source"); }
            var unloadnati = source.UnloadVehicle(garageSlot);
            var obshto = source.GetVehicle(garageSlot).Trunk.Count;
            return $"Unloaded {unloadnati}/{obshto} products at {source.Name}";
        }
        public string GetStorageStatus(string storageName)

        {

            Storage abc = storagi.Where(x => x.Name == storageName).First();
            var producti = abc.Producks.Count;
            abc.Producks.GroupBy(x=>x.tip).Select().OrderByDescending(p=>p.)

        }


    }
}
