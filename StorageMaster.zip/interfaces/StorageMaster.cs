﻿using StorageMaster.entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StorageMaster.interfaces
{
    public class master
    {
       
        Vehicle kola;

        List<Product> pool;
        List<Storage> storagi;
        public master()
        {
            pool = new List<Product>();
            storagi = new List<Storage>();
        }
        public string AddProduct(string type, double price)
        {
            
            switch (type)
            {
                case "Gpu":
                    Gpu gpu = new Gpu(price);
                    pool.Add(gpu);
                    return $"Added {type} to pool";


                case "Ram":
                    Ram ram = new Ram(price);
                    pool.Add(ram);
                    return $"Added {type} to pool";

                case "SolidStateDrive":
                    SolidStateDrive ssd = new SolidStateDrive(price); pool.Add(ssd);
                    return $"Added {type} to pool";

                case "HardDrive":
                    HardDrive hard = new HardDrive(price);
                    pool.Add(hard);
                    return $"Added {type} to pool";

                default:
                    throw new Exception("Invalid product type!");
            }
        }
        public string RegisterStorage(string type, string name)
        {
            switch (type)
            {
                case "AutomatedWarehouse":
                    AutomatedWarehouse gpu = new AutomatedWarehouse(name);
                    storagi.Add(gpu);
                    return $"Registered {name}";

                case "DistributionCenter":
                    DistributionCenter ram = new DistributionCenter(name);
                    storagi.Add(ram);
                    return $"Registered {name}";

                case "Warehouse":
                    Warehouse ssd = new Warehouse(name);
                    storagi.Add(ssd);
                    return $"Registered {name}";


                default:

                    return "Invalid storage type!";

            }
        }
        public string SelectVehicle(string type, int gslot)
        {
            var car = storagi.Where(x => x.Name == type).FirstOrDefault();
            var car2 = car.GetVehicle(gslot);
            kola = car2;
            return "Selected " + car2.tip;



        }
        public string LoadVehicle(IEnumerable<string> productNames)
        {


            foreach (var item in productNames)
            {
                Product product = this.pool.FirstOrDefault(p => p.GetType().Name == item);
                if (product == null) { throw new Exception(item + " is out of stock!"); }
                product = pool.Last(p => p.GetType().Name == item);

                if (kola.IsFull)
                {
                    return "Loaded " + kola.Trunk.Count + "/" + productNames.Count() + "products into " + kola.tip;
                }
                kola.LoadProduct(pool.Where(x => x.tip == item).First());
                pool.Remove(pool.Where(x => x.tip == item).First());

            }


            return "Loaded " + kola.Trunk.Count + "/" + productNames.Count() + "products into " + kola.tip;
        }


        public string SendVehicleTo(string sourceName, int sourceGarageSlot, string destinationName)

        {
            Storage source;
             source = storagi.Where(x => x.Name == sourceName).FirstOrDefault(); if(source==null) { throw new Exception("Invalid source"); }
            var prevozno = source.GetVehicle(sourceGarageSlot);
            Storage destination;
             destination = storagi.Where(x => x.Name == destinationName).FirstOrDefault(); if(destination==null) { throw new Exception("Invalid destination"); }
            var destinationindex = source.SendVehicleTo(sourceGarageSlot, destination);
            return $"Sent {prevozno.tip} to {destination.Name} (slot {destinationindex})";
        }
        public string UnloadVehicle(string storageName, int garageSlot)
        {Storage source;
             source = storagi.Where(x => x.Name == storageName).First();
            var obshto = source.GetVehicle(garageSlot).Trunk.Count;
            
            var unloadnati = source.UnloadVehicle(garageSlot);
            
            return $"Unloaded {unloadnati}/{obshto} products at {source.Name}";
        }
        public string GetStorageStatus(string storageName)

        {

            Storage abc = storagi.Where(x => x.Name == storageName).First();
            var producti = abc.Producks.Capacity;
            var produktite = abc.Producks.GroupBy(x => x.tip).Select(group => new { Name = group.Key, Count = group.Count() }).OrderByDescending(x => x.Count).ThenBy(p => p.Name).Select(p => $"{p.Name} ({p.Count})").ToArray();
            var obshto = abc.Producks.Sum(x => x.Weight);
            var stoki = string.Format("Stock({0}/{1}): [{2}]", obshto, producti, string.Join(", ", produktite));

            var garaj = abc.Garage.ToArray();
            var koli = garaj.Select(vehicle => vehicle?.GetType().Name ?? "empty").ToArray();

            var garaji = string.Format("Garage: [{0}]", string.Join("|", koli));
            return stoki + Environment.NewLine + garaji;

        }
        public string GetSummary()
        {
            var obshto = new StringBuilder();
            var storigi = storagi.OrderByDescending(s => s.Producks.Sum(p => p.Price)).ToArray();
            foreach (var item in storigi)
            {
                obshto.AppendLine($"{item.Name}:");
                var pari = item.Producks.Sum(p => p.Price);
                obshto.AppendLine($"Storage worth: ${pari:F2}");

            }


            return obshto.ToString().TrimEnd('\r', '\n');
        }
    }
}

