﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StorageMaster.interfaces
{
    public abstract class Vehicle
    {
        

        private int capacity;

        public int Capacity
        {
            get { return capacity; }
            set { capacity = value; }
        }
        private readonly List<Product> trunk;

        public IReadOnlyCollection<Product> Trunk
        {
            get { return trunk; }
           
        }
        public bool IsFull => this.Trunk.Sum(c => c.Weight) >= Capacity;
        //private bool isFull;

        // public bool IsFull
        //{
        //  get { return isFull; }
        //set
        //{
        //  double suma = 0;
        //foreach (var item in trunk)
        //{
        //  item.Weight += suma;
        //}
        //if (suma >= Capacity) { isFull = value=true; }




        //}
        //}
        //private bool isEmpty;

        //public bool IsEmpty
        //{
        //  get { return isEmpty; }
        //set
        //{


        //  if (trunk.Count ==0) { isEmpty = value = true; }




        //}
        //}
        public bool IsEmpty => !this.Trunk.Any();
        public Vehicle(int cap)
        {
            this.Capacity = cap;
            trunk = new List<Product>();
        }
        public void LoadProduct(Product produkt)
        {
            if (IsFull) { throw new Exception("Vehicle is full!"); } else { trunk.Add(produkt); }
            




        }
        public Product Unload()
        {
            if (this.IsEmpty) { throw new Exception("No Products left!"); } else { var last = trunk.LastOrDefault(); this.trunk.RemoveAt(this.trunk.Count-1);return last; }




        }
        public string tip = "Vehicle";

        

    }
}
