﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StorageMaster.Entities.Products;
using StorageMaster.Entities.Storage;
using StorageMaster.Entities.Vehicles;
namespace StorageMaster.Entities.Storage
{
    class Warehouse : Storage
    {
        public static readonly List<Vehicle> prevozni = new List<Vehicle>() { new Semi(), new Semi(), new Semi() };



        public Warehouse(string name) : base(name,capacity: 10, garageslots:10, vehicles:prevozni)
        {

        }
    }
}
