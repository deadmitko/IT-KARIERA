﻿using StorageMaster.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StorageMaster.entities
{
    class AutomatedWarehouse:Storage
    {
        public static readonly<Vehicle> prevozni = 
        { new Truck();  }
        public AutomatedWarehouse(string name):base(name,1.0,2.0,vehicles)
        {

        }
    }
}
