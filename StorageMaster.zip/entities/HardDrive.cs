﻿using StorageMaster.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StorageMaster.entities
{
    class HardDrive:Product
    {
        public HardDrive(double price) : base(price,1.00)
        {
            tip = "HardDrive";
        }

    }
}
