﻿using StorageMaster.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StorageMaster.entities
{
    class AutomatedWarehouse : Storage
    {
        public static readonly List<Vehicle> prevozni = new List<Vehicle>() { new Truck() };
    
    
        
        public AutomatedWarehouse(string name):base(name,1,2,prevozni)
        {

        }
    }
}
