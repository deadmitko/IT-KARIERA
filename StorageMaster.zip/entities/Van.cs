﻿using StorageMaster.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StorageMaster.entities
{
    class Van:Vehicle
    {
        
        public Van() : base(2)
        {
            tip = "Van";
        }

    }
}
