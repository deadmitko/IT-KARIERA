﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StorageMaster.Entities.Products;
using StorageMaster.Entities.Storage;
using StorageMaster.Entities.Vehicles;

namespace StorageMaster.Entities.Storage
{
   public abstract class Storage
    {
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private int capacity;

        public int Capacity
        {
            get { return capacity; }
            set { capacity = value; }
        }
        private int garageslots;

        public int GarageSlots
        {
            get { return garageslots; }
            set { garageslots = value; }
        }

        public  readonly List<Product> products;

        public IReadOnlyCollection<Product> Products
        {
            get { return products; }
            
        }
        public Vehicle[] garage;

        public IReadOnlyCollection<Vehicle> Garage
        {
            get { return garage; }
            
        }
        public double obshtopari => products.Sum(x => x.Price);
        public bool IsFull => this.products.Sum(p => p.Weight) >= this.Capacity;
        public bool IsPulen => this.garage.Any(p=>p==null);
        //private bool isFull;

        //   public bool IsFull
        //{
        //  get { return isFull; }
        //set
        //{
        //  double suma = 0;
        //foreach (var item in producks)
        //{
        //  item.Weight += suma;
        //}
        //if (suma >= Capacity) { isFull = value = true; }




        //}
        //}
        //private bool pulen;

        //public bool Pulen
        //{
          //  get { return pulen; }
           // set
            //{
              //  if (Garage.Count >= slots) { pulen = value = true; }

                   

            //}
        //}

        public Storage(string name,int capacity,int garageslots,IEnumerable<Vehicle> vehicles)
        {
            this.Name = name;
            this.Capacity = capacity;
            this.GarageSlots = garageslots;
            int i = 0;
            products = new List<Product>();
            this.garage = new Vehicle[garageslots];
            foreach (var item in vehicles)
            {
                garage[i++] = item;
            }
        }
       public Vehicle GetVehicle(int slot)
        {
            
            if (slot >= garageslots) { throw new InvalidOperationException("Error: Invalid garage slot!");  }
            if (garage[slot] == null) { throw new InvalidOperationException("Error: No vehicle in this garage slot!"); }
            return garage[slot];




        }
        public int SendVehicleTo(int slot, Storage destination)
        {
            var vehicle = GetVehicle(slot);
            if (!destination.IsPulen) { throw new InvalidOperationException("No room in garage"); }

            
                garage[slot] = null;
            var kudeesvoboden = 0;
            for (int i = 0; i < destination.garage.Length; i++)
            {
                if (destination.garage[i] == null) { kudeesvoboden = i;break; }
            }
                destination.garage[kudeesvoboden] = vehicle;
            
            return kudeesvoboden;





        }
        public int UnloadVehicle(int garageslot)
        {
            
            if (IsFull) { throw new InvalidOperationException("Error: Storage is full!"); }
            var prevozno = GetVehicle(garageslot);
            var obshto = 0;
            while (!this.IsFull && !prevozno.IsEmpty)
            {
                var prodkt =prevozno.Unload();
                this.products.Add(prodkt);
                obshto++; 
            }

            return obshto;



        }
    }
}
