﻿
using System;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StorageMaster.Entities.Products;
using StorageMaster.Entities.Storage;
using StorageMaster.Entities.Vehicles;

namespace StorageMaster
{
    public class Engine
    {
              StorageMaster storageMaster;
        public Engine()
        {
            storageMaster = new StorageMaster();
        }
        public void Run()
        {

            
            var input = Console.ReadLine().Split().ToList();

            string output = "";
            

            while (input[0] != "END")
            {
                try
                {
                    switch (input[0])
                    {
                        case "AddProduct":
                            {
                                string name = input[1];
                                var price = double.Parse(input[2]);

                                output = storageMaster.AddProduct(name, price);

                                break;
                            }
                        case "RegisterStorage":
                            {
                                var type = input[1];
                                var name = input[2];

                                output = storageMaster.RegisterStorage(type, name);
                                break;
                            }
                        case "SelectVehicle":
                            {
                                var storageName = input[1].ToString();
                                var garageSlot = int.Parse(input[2]);

                                output = storageMaster.SelectVehicle(storageName, garageSlot);
                                break;
                            }
                        case "LoadVehicle":
                            {
                                var productNames = input;
                                productNames.RemoveAt(0);

                                output = storageMaster.LoadVehicle(productNames);
                                break;
                            }
                        case "SendVehicleTo":
                            {
                                var sourceName = input[1].ToString();
                                var sourceGarageSlot = int.Parse(input[2]);
                                var destinationName = input[3];

                                output = storageMaster.SendVehicleTo(sourceName, sourceGarageSlot, destinationName);
                                break;
                            }
                        case "UnloadVehicle":
                            {
                                var sourceName = input[1].ToString();
                                var garageSlot = int.Parse(input[2].ToString());

                                output = storageMaster.UnloadVehicle(sourceName, garageSlot);
                                break;
                            }
                        case "GetStorageStatus":
                            {
                                var storageName = input[1].ToString();
                                output = storageMaster.GetStorageStatus(storageName);
                                break;
                            }
                  
                    }
                    Console.WriteLine(output);
                }
                catch (Exception ex) { Console.WriteLine(ex.Message); }


                input = Console.ReadLine().Split().ToList();
            }
            Console.WriteLine(storageMaster.GetSummary());
        }
    }
}
