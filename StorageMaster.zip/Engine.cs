﻿using StorageMaster.interfaces;
using System;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StorageMaster
{
    public class Engine
    {
        public void Engine1()
        {
            try
            {
                master storageMaster = new master();
                string input = Console.ReadLine();
                string output = "";
                while (input != "END")
                {
                    switch (input)
                    {
                        case "AddProduct":
                            {
                                string name = input[0].ToString();
                                var price = double.Parse(input[1].ToString());

                                output = storageMaster.AddProduct(name, price);
                                break;
                            }
                        case "RegisterStorage":
                            {
                                var type = input[0].ToString();
                                var name = input[1].ToString();

                                output = storageMaster.RegisterStorage(type, name);
                                break;
                            }
                        case "SelectVehicle":
                            {
                                var storageName = input[0].ToString();
                                var garageSlot = int.Parse(input[1].ToString());

                                output = storageMaster.SelectVehicle(storageName, garageSlot);
                                break;
                            }
                        case "LoadVehicle":
                            {
                                var productNames = input.Split().ToList();
                                productNames.RemoveAt(0);

                                output = storageMaster.LoadVehicle(productNames);
                                break;
                            }
                        case "SendVehicleTo":
                            {
                                var sourceName = input[0].ToString();
                                var sourceGarageSlot = int.Parse(input[1].ToString());
                                var destinationName = input[2].ToString();

                                output = storageMaster.SendVehicleTo(sourceName, sourceGarageSlot, destinationName);
                                break;
                            }
                        case "UnloadVehicle":
                            {
                                var sourceName = input[0].ToString();
                                var garageSlot = int.Parse(input[1].ToString());

                                output = storageMaster.UnloadVehicle(sourceName, garageSlot);
                                break;
                            }
                        case "GetStorageStatus":
                            {
                                var storageName = input[0].ToString();
                                output = storageMaster.GetStorageStatus(storageName);
                                break;
                            }

                    }
                    Console.WriteLine(output);
                }
                Console.WriteLine(storageMaster.GetSummary());
            }
            catch (Exception ex) { Console.WriteLine(ex); }
        }
    }
}
