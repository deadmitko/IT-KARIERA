﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StorageMaster.Entities.Products;
using StorageMaster.Entities.Storage;
using StorageMaster.Entities.Vehicles;

namespace StorageMaster.Entities.Storage
{
    class AutomatedWarehouse : Storage
    {
        public static readonly List<Vehicle> prevozni = new List<Vehicle>() { new Truck() };
    
    
        
        public AutomatedWarehouse(string name):base(name,capacity :1, garageslots: 2,vehicles:prevozni)
        {

        }
    }
}
