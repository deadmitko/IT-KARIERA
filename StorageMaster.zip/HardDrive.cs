﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StorageMaster.Entities.Products;
using StorageMaster.Entities.Storage;
using StorageMaster.Entities.Vehicles;

namespace StorageMaster.Entities.Products
{
    class HardDrive:Product
    {
        public HardDrive(double price) : base(price,1.00)
        {
            tip = "HardDrive";
        }

    }
}
