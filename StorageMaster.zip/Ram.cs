﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using StorageMaster.Entities.Products;
using StorageMaster.Entities.Storage;
using StorageMaster.Entities.Vehicles;

namespace StorageMaster.Entities.Products
{
    class Ram:Product
    {
        public Ram(double price) : base(price, 0.1)
        {
            tip = "Ram";
        }

    }
}
