﻿using StorageMaster.entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StorageMaster.interfaces
{
    class StorageMaster
    {
        Vehicle prevozno;
        Vehicle kola;
        List<Product> pool = new List<Product>();
        List<Storage> storagi = new List<Storage>();
        public string AddProduct(string type, double price)
        {

            switch (type)
            {
                case "Gpu":
                    Gpu gpu = new Gpu(price);
                    pool.Add(gpu);
                    return $"Added {type} to pool";
                    break;
                case "Ram":
                    Ram ram = new Ram(price);
                    pool.Add(ram);
                    return $"Added {type} to pool";
                    break;
                case "SolidStateDrive":
                    SolidStateDrive ssd = new SolidStateDrive(price); pool.Add(ssd);
                    return $"Added {type} to pool";
                    break;
                case "HardDrive":
                    HardDrive hard = new HardDrive(price);
                    pool.Add(hard);
                    return $"Added {type} to pool";
                    break;
                default:
                    throw new Exception("Invalid product type!");
            }
        }
        public string RegisterStorage(string type, string name)
        {
            switch (type)
            {
                case "AutomatedWarehouse":
                    AutomatedWarehouse gpu = new AutomatedWarehouse(name);
                    storagi.Add(gpu);
                    return $"Registered {name}";
                    break;
                case "DistributionCenter":
                    DistributionCenter ram = new DistributionCenter(name);
                    storagi.Add(ram);
                    return $"Registered {name}";
                    break;
                case "Warehouse":
                    Warehouse ssd = new Warehouse(name);
                    storagi.Add(ssd);
                    return $"Registered {name}";
                    break;
                
                default:
                    
                    return "Invalid product type!";
                    
            }
        }
        public string SelectVehicle(string type, int gslot)
        {
            var car = storagi.Where(x=>x.Name==type).First();
             kola = car.Garage.ElementAt(gslot);
            return "Selected " + kola.tip;
            
            
            
        }
        public string LoadVehicle(IEnumerable<string> productNames)
        {
            
            foreach (var item in productNames)
            {
                kola.LoadProduct(pool.Where(x => x.tip == item).First());
                pool.Remove(pool.Where(x => x.tip == item).First());
            }
            return "Loaded " + kola.Trunk.Count + "/" + productNames.Count() + "products into " + kola.tip;

        }




    }
}
