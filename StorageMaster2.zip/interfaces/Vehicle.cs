﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StorageMaster.interfaces
{
    public abstract class Vehicle
    {
        

        private int capacity;

        public int Capacity
        {
            get { return capacity; }
            set { capacity = value; }
        }
        private List<Product> trunk;

        public List<Product> Trunk
        {
            get { return trunk; }
            set { trunk = value; }
        }
        private bool isFull;

        public bool IsFull
        {
            get { return isFull; }
            set
            {
                double suma = 0;
                foreach (var item in trunk)
                {
                    item.Weight += suma;
                }
                if (suma >= Capacity) { isFull = value=true; }
               



            }
        }
        private bool isEmpty;

        public bool IsEmpty
        {
            get { return isEmpty; }
            set
            {
                double suma = 0;
                
                if (trunk.Count ==0) { isEmpty = value = true; }




            }
        }
        public Vehicle(int cap)
        {
            this.Capacity = cap;
            trunk = new List<Product>();
        }
        public void LoadProduct(Product produkt)
        {
            if (isFull) { throw new Exception("Vehicle is full!"); } else { trunk.Add(produkt); }
            




        }
        public void Unload()
        {
            if (IsEmpty) { throw new Exception("No Products left!"); } else { trunk.RemoveAt(trunk.Count - 1); }




        }
        public string tip = "Vehicle";

        

    }
}
