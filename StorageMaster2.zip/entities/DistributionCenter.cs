﻿using StorageMaster.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StorageMaster.entities
{
    class DistributionCenter: Storage
    {
        public static readonly List<Vehicle> prevozni = new List<Vehicle>() { new Van(),new Van(),new Van() };



        public DistributionCenter(string name) : base(name, 2, 5, prevozni)
        {

        }
    }
}
