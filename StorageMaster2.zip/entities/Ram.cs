﻿using StorageMaster.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StorageMaster.entities
{
    class Ram:Product
    {
        public Ram(double price) : base(price, 0.1)
        {
            tip = "Ram";
        }

    }
}
