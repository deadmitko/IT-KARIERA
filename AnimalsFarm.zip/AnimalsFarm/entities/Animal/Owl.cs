﻿using AnimalsFarm.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalsFarm.entities.Animal
{
    public class Owl:Bird
    {
        public Owl(string name, double weight,double wingsize) : base(name, weight,wingsize)
        {



        }
        public override void makeSound()
        {
            Console.WriteLine("Hoot Hoot");
        }

        public override void eat(Food hrana)
        {
            if (hrana.Tip == "Meat") { animalWeight = animalWeight + 0.25 * hrana.Quantity; foodEaten++; } else { Console.WriteLine(animalType + " does not eat " + hrana.Tip); }

        }

    }
}
