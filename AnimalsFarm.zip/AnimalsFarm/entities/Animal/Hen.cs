﻿using AnimalsFarm.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalsFarm.entities.Animal
{
    public class Hen:Bird
    {
        public Hen(string name, double weight, double wingsize) : base(name, weight, wingsize)
        {



        }
        public override void makeSound()
        {
            Console.WriteLine("Cluck");
        }

        public override void eat(Food hrana)
        {
           animalWeight = animalWeight + 0.35 *hrana.Quantity; foodEaten++;

        }
    }
}
