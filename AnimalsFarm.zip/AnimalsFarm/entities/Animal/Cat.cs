﻿using AnimalsFarm.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalsFarm.entities.Animal
{
    public class Cat:Feline
    {
        private string breed;

        public string Breed
        {
            get { return breed; }
            set { breed = value; }
        }

        public Cat(string name, double weight, string livingregion,string breed) : base(name, weight, livingregion)
        {

            this.Breed = breed;

        }
        public override void makeSound()
        {
            Console.WriteLine("Meow");
        }

        public override void eat(Food hrana)
        {
            
            if (hrana.Tip == "Vegetable" || hrana.Tip == "Meat") { animalWeight = animalWeight + 0.3* hrana.Quantity; foodEaten++; } else { Console.WriteLine(animalType + " does not eat " + hrana.Tip); }

        }
        public override string ToString()
        {
            return $"{animalType} [{animalName}, {Breed}, {animalWeight}, {LivingRegion}, {foodEaten}]";
        }
    }
}
