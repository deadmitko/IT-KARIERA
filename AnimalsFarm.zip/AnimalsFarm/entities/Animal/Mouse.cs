﻿using AnimalsFarm.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalsFarm.entities.Animal
{
    public class Mouse : Mammal
    {
        public Mouse(string name, double weight, string livingregion) : base(name, weight, livingregion)
        {



        }

        public override void makeSound()
        {
            Console.WriteLine("Squeak");
        }

        public override void eat(Food hrana)
        {
            if (hrana.Tip == "Vegetable" || hrana.Tip == "Fruit") { animalWeight = animalWeight + 0.1 * hrana.Quantity; foodEaten++; } else { Console.WriteLine(animalType + " does not eat " + hrana.Tip); }

        }
    }
}