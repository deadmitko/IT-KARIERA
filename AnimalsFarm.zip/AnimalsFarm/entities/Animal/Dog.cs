﻿using AnimalsFarm.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalsFarm.entities.Animal
{
    public class Dog:Mammal
    {
        public Dog(string name, double weight,  string livingregion) : base(name, weight, livingregion)
        {



        }

        public override void makeSound()
        {
            Console.WriteLine("Woof!");
        }

        public override void eat(Food hrana)
        {
            if (hrana.Tip == "Meat") { animalWeight = animalWeight + 0.4 * hrana.Quantity; foodEaten++; } else { Console.WriteLine(animalType + " does not eat " + hrana.Tip); }

        }
    }
}
