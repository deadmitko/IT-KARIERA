﻿using AnimalsFarm.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalsFarm.entities
{
    public class Meat:Food
    {
        public Meat(int quanity) : base(quanity)
        {





        }
        private string tip = "Meat";

        public string Tip
        {
            get { return tip; }
            set { tip = value; }
        }
    }
}
