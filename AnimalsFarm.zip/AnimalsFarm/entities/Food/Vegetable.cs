﻿using AnimalsFarm.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalsFarm.entities
{
    public class Vegetable:Food
    {
        public Vegetable(int quanity):base(quanity)
        {



        }

        private string tip = "Vegetable";

        public string Tip
        {
            get { return tip; }
            set { tip = value; }
        }
    }
}
