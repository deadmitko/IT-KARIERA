﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalsFarm.interfaces
{
    public abstract class Bird : Animal
    {
        public double WingSize { get; set; }
        public Bird(string name, double weight, double wingsize) : base(name, weight)
        {

            this.WingSize = wingsize;

        }
        public override string ToString()
        {
            return $"{animalType} [{animalName}, {WingSize}, {animalWeight}, {foodEaten}]";
        }


    }
}
