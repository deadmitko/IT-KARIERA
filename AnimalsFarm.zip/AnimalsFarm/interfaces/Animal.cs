﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalsFarm.interfaces
{
   public abstract class Animal
    {
        public string animalName { get; set; }
        public string animalType { get; set; }
        public double animalWeight { get; set; }
        public int foodEaten { get; set; }
        public abstract void makeSound();
        public abstract void eat(Food hrana);
        public Animal(string name, double weight)
        {
            this.animalName = name;
            this.animalWeight = weight;
           



        }

    }
}
