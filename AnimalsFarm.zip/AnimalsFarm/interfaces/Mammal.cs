﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalsFarm.interfaces
{
    public abstract class Mammal:Animal
    {
        public string LivingRegion { get; set; }
        public Mammal(string name, double weight,string livingregion) : base(name, weight)
        {

            this.LivingRegion = livingregion;
           
        }
        public override string ToString()
        {
            return $"{animalType} [{animalName}, {animalWeight}, {LivingRegion}, {foodEaten}]";
        }
    }
}
