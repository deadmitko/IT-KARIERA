﻿using AnimalsFarm.entities;
using AnimalsFarm.entities.Animal;
using AnimalsFarm.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalsFarm
{
    class Program
    {
        static void Main(string[] args)
        {
            Hen hen = null;
            Owl owl = null;
            Mouse mice = null;
            Cat cat = null;
            Dog dog = null;
            Tiger tiger = null;
            Seeds seeds = null;
            Fruit fruit = null;
            Meat meat = null;
            Vegetable veg = new Vegetable(1);
            string[] input = Console.ReadLine().Split().ToArray();
            while (input[0] != "End")
            {
                switch (input[0])
                {
                    case "Hen":
                        hen = new Hen(input[1], double.Parse(input[2]), double.Parse(input[3]));
                        hen.makeSound();
                        input = Console.ReadLine().Split().ToArray();
                        switch (input[0])
                        {
                            case "Vegetable":
                                hen.eat(veg= new Vegetable(int.Parse(input[1])));
                                break;
                            case "Fruit":
                                hen.eat(fruit = new Fruit(int.Parse(input[1])));
                                break;
                            case "Meat":
                                hen.eat(meat = new Meat(int.Parse(input[1])));
                                break;
                            case "Seeds":
                                hen.eat(seeds = new Seeds(int.Parse(input[1])));
                                break;
                        } 
                        break;
                    case "Owl":
                        owl = new Owl(input[1], double.Parse(input[2]), double.Parse(input[3]));
                        owl.makeSound();
                        input = Console.ReadLine().Split().ToArray();
                        switch (input[0])
                        {
                            case "Vegetable":
                                hen.eat(veg = new Vegetable(int.Parse(input[1])));
                                break;
                            case "Fruit":
                                hen.eat(fruit = new Fruit(int.Parse(input[1])));
                                break;
                            case "Meat":
                                hen.eat(meat = new Meat(int.Parse(input[1])));
                                break;
                            case "Seeds":
                                hen.eat(seeds = new Seeds(int.Parse(input[1])));
                                break;
                        }

                        break;
                    case "Mouse":
                         mice = new Mouse(input[1], double.Parse(input[2]), input[3]);
                        mice.makeSound();
                        input = Console.ReadLine().Split().ToArray();
                        switch (input[0])
                        {
                            case "Vegetable":
                                hen.eat(veg = new Vegetable(int.Parse(input[1])));
                                break;
                            case "Fruit":
                                hen.eat(fruit = new Fruit(int.Parse(input[1])));
                                break;
                            case "Meat":
                                hen.eat(meat = new Meat(int.Parse(input[1])));
                                break;
                            case "Seeds":
                                hen.eat(seeds = new Seeds(int.Parse(input[1])));
                                break;
                        }
                        break;
                    case "Cat":
                        cat = new Cat(input[1], double.Parse(input[2]), input[3],input[4]);
                        cat.makeSound();
                        input = Console.ReadLine().Split().ToArray();
                        switch (input[0])
                        {
                            case "Vegetable":
                                hen.eat(veg = new Vegetable(int.Parse(input[1])));
                                break;
                            case "Fruit":
                                hen.eat(fruit = new Fruit(int.Parse(input[1])));
                                break;
                            case "Meat":
                                hen.eat(meat = new Meat(int.Parse(input[1])));
                                break;
                            case "Seeds":
                                hen.eat(seeds = new Seeds(int.Parse(input[1])));
                                break;
                        }
                        break;
                    case "Dog":
                        dog = new Dog(input[1], double.Parse(input[2]), input[3]);
                        dog.makeSound();
                        input = Console.ReadLine().Split().ToArray();
                        switch (input[0])
                        {
                            case "Vegetable":
                                hen.eat(veg = new Vegetable(int.Parse(input[1])));
                                break;
                            case "Fruit":
                                hen.eat(fruit = new Fruit(int.Parse(input[1])));
                                break;
                            case "Meat":
                                hen.eat(meat = new Meat(int.Parse(input[1])));
                                break;
                            case "Seeds":
                                hen.eat(seeds = new Seeds(int.Parse(input[1])));
                                break;
                        }
                        break;
                    case "Tiger":
                        tiger = new Tiger(input[1], double.Parse(input[2]), input[3], input[4]);
                        tiger.makeSound();
                        input = Console.ReadLine().Split().ToArray();
                        switch (input[0])
                        {
                            case "Vegetable":
                                hen.eat(veg = new Vegetable(int.Parse(input[1])));
                                break;
                            case "Fruit":
                                hen.eat(fruit = new Fruit(int.Parse(input[1])));
                                break;
                            case "Meat":
                                hen.eat(meat = new Meat(int.Parse(input[1])));
                                break;
                            case "Seeds":
                                hen.eat(seeds = new Seeds(int.Parse(input[1])));
                                break;
                        }
                        break;

                }




            }
            
        }
    }
}
