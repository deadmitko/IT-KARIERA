﻿using BorderControl.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BorderControl
{
    public interface ICivilians
    {
        string Name { get;  }
        string ID { get;  }
    }
}
