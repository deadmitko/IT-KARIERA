﻿using BorderControl.entities;
using BorderControl.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BorderControl
{
    class Zadacha2
    {
        static void Main2(string[] args)
        {



            IList<IBirthable> births = new List<IBirthable>();
            IList<ICivilians> civilians = new List<ICivilians>();
            string[] input = Console.ReadLine().Split().ToArray();
            while (input[0] != "End")
            {
                if (input[0] == "Citizen")
                {
                    Person person = new Person(input[1], int.Parse(input[2]), input[3], input[4]);
                    births.Add(person);



                }
                else if (input[0] == "Robot")
                {
                    Robot robot = new Robot(input[0], input[1]);
                    civilians.Add(robot);




                }
                else if (input[0] == "Pet")
                {


                    Pet pet = new Pet(input[1], input[2]);
                    births.Add(pet);


                }

                input = Console.ReadLine().Split().ToArray();





            }

            string godina = Console.ReadLine();
            Getbirth(births, godina);


        }





        private static void Getbirth(IList<IBirthable> pets, string godina)
        {
            foreach (var item in pets)
            {
                string citizenidlast = item.BirthDate.Substring(item.BirthDate.Length - godina.Length);
                
                if (citizenidlast == godina)
                {
                    Console.WriteLine(item.BirthDate);
                }

            }


        }






        
    }
}
