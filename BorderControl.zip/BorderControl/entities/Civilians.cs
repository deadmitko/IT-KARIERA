﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BorderControl.entities
{
    public abstract class Civilians : ICivilians
    {
        private string name;
        private string id;
        public Civilians(string name,string id)
        {
            this.Name = name;
            this.ID = id;
        }
        public string Name
        {

            get
            { return this.name; }

            private set { this.name = value; }

        }
        public string ID
        {

            get
            { return this.id; }

            private set { this.id = value; }

        }
    }
}
