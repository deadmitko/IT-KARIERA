﻿using BorderControl.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BorderControl.entities
{
    public class Person:Civilians,IBirthable,IBuyer
    {
        private int age;

        public int Age
        {
            get { return age; }
            set { age = value; }
        }
        private string birthdate;

        public string BirthDate
        {
            get { return birthdate; }
            set { birthdate = value; }
        }

        public int Food { set; get; }
        
        
        public Person(string name,int age,string id,string birthdate):base(name,id)
        {
            this.Age = age;
            this.BirthDate = birthdate;
        }

        public void BuyFood()
        {
            Food+=10;
        }
    }
}
