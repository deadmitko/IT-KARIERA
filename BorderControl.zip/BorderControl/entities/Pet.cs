﻿using BorderControl.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BorderControl.entities
{
    public class Pet:IBirthable

    {
        public Pet(string name,string birthdate)
        {
            this.Name = name;
            this.BirthDate = birthdate;
        }
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        private string birthdata;

        public string BirthDate
        {
            get { return birthdata; }
            set { birthdata = value; }
        }

    }

}
