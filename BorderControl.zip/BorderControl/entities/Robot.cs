﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BorderControl.entities
{
   public class Robot:Civilians
    {
        public Robot(string name,string id):base(name,id)
        {

        }
    }
}
