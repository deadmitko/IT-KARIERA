﻿using BorderControl.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BorderControl.entities
{
    public class Rebel:IBuyer
    {
        private int age;

        public int Age
        {
            get { return age; }
            set { age = value; }
        }
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        private string group;

        public string Group
        {
            get { return group; }
            set { group = value; }
        }

        public int Food { set; get; }

        

        public Rebel(string name,int age,string group)
        {
            this.Name = name;
            this.Age = age;
            this.Group = group;



        }

        public void BuyFood()
        {
            
            Food+=5;
        }
    }
}
