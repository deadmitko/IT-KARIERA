﻿using BorderControl.entities;
using BorderControl.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BorderControl
{
    class Zadacha1
    {
        static void Main1(string[] args)
        {
            //zadacha1
            IList<ICivilians> civilians = new List<ICivilians>();
            string[] input = Console.ReadLine().Split().ToArray();
            while (input[0] != "End")
            {
                if (input.Length == 3)
                {
                    Person person = new Person(input[0], int.Parse(input[1]), input[2]);
                    civilians.Add(person);



                }
                else
                {
                    Robot robot = new Robot(input[0], input[1]);
                    civilians.Add(robot);




                }

                input = Console.ReadLine().Split().ToArray();





            }
            string illigalidTemplate = Console.ReadLine();
            ArrestIlligalCivilians(civilians, illigalidTemplate);

            







        }
        private static void ArrestIlligalCivilians(IList<ICivilians> civilians, string illigalidTemplate)
        {
            foreach (var item in civilians)
            {
                string citizenidlast = item.ID.Substring(item.ID.Length - illigalidTemplate.Length);

                if (citizenidlast == illigalidTemplate)
                {
                    Console.WriteLine(item.ID);




                }
            }
        }
    }
}
