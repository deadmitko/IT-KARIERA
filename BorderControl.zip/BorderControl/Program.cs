﻿using BorderControl.entities;
using BorderControl.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BorderControl
{

    
    class Program
    {

       


        static void Main(string[] args)
        {



            
            HashSet<ICivilians> buyers2 = new HashSet<ICivilians>();
            IList<string> imena = new List<string>();
            
            string[] input = Console.ReadLine().Split().ToArray();
            while (input[0] != "End")
            {

                for (int i = 0; i < int.Parse(input[0]); i++)
                {
                    input = Console.ReadLine().Split().ToArray();
                    if (input[3] == "")
                    {
                        Rebel buntovnik = new Rebel(input[0], int.Parse(input[1]), input[2]);
                        buntovnik.BuyFood();

                        buyers2.Add(buntovnik);


                    }

                    else
                    {


                        Person grajdanin = new Person(input[1], int.Parse(input[2]), input[3], input[4]);
                        grajdanin.BuyFood();

                        buyers2.Add(grajdanin);


                    }
                }
                 input = Console.ReadLine().Split().ToArray();
                    if (input[0] != "End")
                    {
                        
                         GetFood(births, godina);
                    }
                    else
                    {

                        

                    }
                }
                

                
                




            }
          private static void GetFood(IList<ICivilians> pets, string imena)
                  {
                      foreach (var item in pets)
                      {
                          if (item.Name == imena) { }
                          
                        
          
                      }
          
          
                  }

            
            
            

        }





        





       
    }

