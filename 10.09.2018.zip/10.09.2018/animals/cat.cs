﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace animals
{
    public class cat:Animal
    {
        public cat(string name, string favouritefood) : base(name, favouritefood)
        {




        }
        public override string ExplainMyself()
        {
            return base.ExplainMyself()+Environment.NewLine + "MEEOW";
        }



    }
}
