﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace animals
{
    public class Animal
    {
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        private string favouritefood;

        public string FavouriteFood
        {
            get { return favouritefood; }
            set { favouritefood = value; }
        }
        public Animal(string name,string favouritefood) { this.Name = name;this.FavouriteFood = favouritefood; }
        public virtual string ExplainMyself()
        {

            return "I am "+Name+ "and my fovourite food is "+FavouriteFood;



        }

    }
}
