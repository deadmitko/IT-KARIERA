﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace animals
{
    class dog:Animal
    {
        
            public dog(string name, string favouritefood) : base(name, favouritefood)
            {




            }
            public override string ExplainMyself()
            {
                return base.ExplainMyself() + Environment.NewLine + "DJAAF";
            }
        




    }
}
