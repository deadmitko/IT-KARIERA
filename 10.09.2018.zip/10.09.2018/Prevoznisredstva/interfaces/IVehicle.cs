﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prevoznisredstva.interfaces
{
    public interface IVehicle
    {
         double Fuel { get; set; }
        double Consumption { get; set; }
        double TankCap { get; set; }
        void Drive(double km);
        void Refuel(double fuel);




    }
}
