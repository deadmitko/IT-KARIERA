﻿using System;
using Prevoznisredstva.entities;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Prevoznisredstva.interfaces;

namespace Prevoznisredstva
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] input;
            Car kola = null;
            Truck kamion=null;
            Bus avtobus = null;
            for (int i = 0; i < 3; i++)
            {
                input =Console.ReadLine().Split().ToArray();

                switch (input[0])
                {
                    case "Car":
                        if (double.Parse(input[1]) > double.Parse(input[3]))
                        {
                            kola = new Car(double.Parse("0"), double.Parse(input[2]), double.Parse(input[3]));
                        }
                        else { kola = new Car(double.Parse(input[1]), double.Parse(input[2]), double.Parse(input[3])); }
                        break;
                    case "Truck":
                        if (double.Parse(input[1]) > double.Parse(input[3]))
                        {
                            kamion = new Truck(double.Parse("0"), double.Parse(input[2]), double.Parse(input[3]));
                        }
                        else { kamion = new Truck(double.Parse(input[1]), double.Parse(input[2]), double.Parse(input[3])); }
                        break;
                    case "Bus":
                        if (double.Parse(input[1]) >double.Parse(input[3]))
                        {
                            avtobus = new Bus(double.Parse("0"), double.Parse(input[2]), double.Parse(input[3]));
                        }
                        else { avtobus = new Bus(double.Parse(input[1]), double.Parse(input[2]), double.Parse(input[3])); }
                        break;
                }
            }
            int n = int.Parse(Console.ReadLine());
            for (int i = 0; i < n; i++)
            {
                input = Console.ReadLine().Split().ToArray();
                switch (input[0])
                {
                    
                    case "Drive":
                        if (input[1] == "Car")
                        {
                            kola.Drive(double.Parse(input[2]));
                        }
                        else if (input[1] == "Truck")
                        {
                            kamion.Drive(double.Parse(input[2]));

                        }
                        else 
                        {

                            avtobus.Drive(double.Parse(input[2]));
                        }
                        break;
                    case "DriveEmpty":

                        avtobus.Consumption = avtobus.Consumption - 1.4;
                            avtobus.Drive(double.Parse(input[2]));
                        avtobus.Consumption = avtobus.Consumption + 1.4;

                        break;

                        

                        
                    case "Refuel":
                        if (input[1] == "Car")
                        {
                            kola.Refuel(double.Parse(input[2]));
                        }
                        else if (input[1] == "Truck")
                        {
                            kamion.Refuel(double.Parse(input[2]));

                        }
                        else
                        {
                            avtobus.Refuel(double.Parse(input[2]));



                        }
                        break;





                }
               
            }
            Console.WriteLine("Car: {0:f2}",  kola.Fuel);
            Console.WriteLine("Truck: {0:f2}", + kamion.Fuel);
            Console.WriteLine("Bus: {0:f2}", +avtobus.Fuel);
        }
    }
}
