﻿using Prevoznisredstva.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prevoznisredstva.entities
{
    public class Truck : IVehicle
    {
        private double fuel;
        public double Fuel
        {
            get { return this.fuel; }
            set
            {
                if (value < 0)
                {
                    Console.WriteLine("Fuel must be a positive number");
                }
                else
                {
                    this.fuel = value;


                }
            }
        }
        public double Consumption { get; set ; }
        public double TankCap { get; set; }

        public void Drive(double km)
        {

            if (Consumption * km > Fuel)
            {
                Console.WriteLine("Truck needs refueling");
            }
            else {
                Fuel =Fuel- Consumption * km; Console.WriteLine("Truck travelled "+km+" km");
            }
        }

        public void Refuel(double fuel)
        {
            if (fuel > 0)
            {
                if (this.Fuel + fuel <= TankCap)
                {
                    Fuel = Fuel + fuel*0.95;
                }
                else
                {
                    Console.WriteLine("Cannot fit " + fuel + " fuel in the tank");


                }
            }
            else { Console.WriteLine("Fuel must be a positive number"); }
        }
        public Truck(double fuel, double consumption,double tankcap)
        {
            this.Fuel = fuel;
            this.Consumption = consumption+1.6;
            this.TankCap = tankcap;
        }
    }
}
