﻿using AnimalsFarm.entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalsFarm
{
    class Program
    {
        static void Main(string[] args)
        {
            Vegetable plod = new Vegetable();
            
        }
    }
}
