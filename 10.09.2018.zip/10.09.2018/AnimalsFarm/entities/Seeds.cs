﻿using AnimalsFarm.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalsFarm.entities
{
    class Seeds:Food
    {
        public Seeds(int quantity) : base(quantity) { }



    }
}
