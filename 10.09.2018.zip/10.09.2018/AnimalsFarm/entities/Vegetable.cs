﻿using AnimalsFarm.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalsFarm.entities
{
    class Vegetable:Food
    {
        public Vegetable(int quanity):base(quanity)
        {



        }


    }
}
