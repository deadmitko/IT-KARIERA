﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnimalsFarm.interfaces
{
   public abstract class Animal
    {
        string animalName { get; set; }
        string animalType { get; set; }
        double animalWeight { get; set; }
        int foodEaten { get; set; }
        void makeSound() { }
        void eat(Food hrana) { }
        public Animal(string name, double weight, int foodeaten)
        {
            this.animalName = name;
            this.animalWeight = weight;
            this.foodEaten = foodeaten;



        }

    }
}
