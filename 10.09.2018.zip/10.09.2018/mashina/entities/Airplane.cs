﻿using mashina.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mashina.entities
{
    public class Airplane : IMachine
    {
        public string Type { get; set; }

        public bool Start()
        {
            Console.WriteLine("Car starting");
            return true;
        }

        public bool Stop()
        {
            Console.WriteLine("Car stoping");
            return true;
        }
        public Airplane()
        {
            this.Type = "Airplane";
        }
    }
}
