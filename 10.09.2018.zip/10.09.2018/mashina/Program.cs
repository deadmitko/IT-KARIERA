﻿using mashina.entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mashina
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car = new Car();
            LawnMower lawnMower = new LawnMower();
            Airplane airplane = new Airplane();
            Truck truck = new Truck();

            MachineOperator mo = new MachineOperator(car);
            mo.Start(); //пускаме машината
            mo.Stop(); //спираме машината
            mo.Entity = lawnMower; //сменяме машината
            mo.Start();
            mo.Stop();

        }
    }
}
