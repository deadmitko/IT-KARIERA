﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace mashina.interfaces
{
    public interface IMachine
    {
        string Type { get; set; }
        bool Start();
        bool Stop();
    }
}
