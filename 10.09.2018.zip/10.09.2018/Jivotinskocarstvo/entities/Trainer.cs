﻿using Jivotinskocarstvo.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jivotinskocarstvo.entities
{
    public class Trainer
    {
        public IAnimal entity { get; set; }
        public Trainer(IAnimal jiootno)
        {
            this.entity = jiootno;

        }
        public void Make() { entity.Perform(); }
            
    }
}
