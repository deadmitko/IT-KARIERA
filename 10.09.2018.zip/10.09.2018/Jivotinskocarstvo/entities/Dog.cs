﻿using Jivotinskocarstvo.interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Jivotinskocarstvo.entities
{
    public class Dog : IAnimal
    {
        public string MakeNoise()
        {
            return "Woof!";
        }

        public string MakeTrick()
        {
            return "Hold my paw, human!";
        }

        public string Perform()
        {
            return MakeNoise() + Environment.NewLine + MakeTrick();
        }
    }
}
