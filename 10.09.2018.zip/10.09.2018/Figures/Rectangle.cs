﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Figures
{
    class Rectangle:Shape
    {
        private int length;

        public int Length
        {
            get { return length; }
            set { length = value; }
        }
        private int width;

        public int Width
        {
            get { return width; }
            set { width = value; }
        }

        public override double CalculatePerimeter()
        {
            return 2 * length + 2 * Width;
        }

        public override double CalculateArea()
        {
            return  length * Width;
        }
        public override string Draw()
        {
            return base.Draw() + "Rectangle";
        }
    }
}
