﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;

namespace mysqltest
{
    class Program
    {
        static void Main(string[] args)
        {
            Vsi4ko();
            Vkarai("42342423", "42342342","4324243");
            
        }
        public static void Vsi4ko()
        {
            MySqlConnectionStringBuilder test = new MySql.Data.MySqlClient.MySqlConnectionStringBuilder();
            test.UserID = "root";
            test.Password = "root";
            test.Server = "127.0.0.1";
            test.Database = "test";

            MySqlConnection test2 = new MySqlConnection(test.ToString());

            var komanda = "SELECT * FROM users";
            MySqlCommand komand = new MySqlCommand(komanda, test2);
            test2.Open();
            MySqlDataReader chetec = komand.ExecuteReader();
            while (chetec.Read())
            {

                var id = chetec[0];
                var username = chetec[1];
                var password = chetec[2];
                Console.Write(id + "," + username + "," + password);
                Console.WriteLine();
            }


            chetec.Close();
            test2.Close();


        }
        public static void Vkarai(string username,string password,string email)
        {
            MySqlConnectionStringBuilder test = new MySql.Data.MySqlClient.MySqlConnectionStringBuilder();
            test.UserID = "root";
            test.Password = "root";
            test.Server = "127.0.0.1";
            test.Database = "test";

            MySqlConnection test2 = new MySqlConnection(test.ToString());

            var komanda = "INSERT INTO users (username, password,email)VALUES("+username+"," +password+ "," + password+")";

            MySqlCommand komand = new MySqlCommand(komanda, test2);
            test2.Open();
            komand.ExecuteNonQuery();
            


            
            test2.Close();


        }

    }
}
